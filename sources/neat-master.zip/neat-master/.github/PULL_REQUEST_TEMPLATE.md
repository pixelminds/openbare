Got some code for us? Awesome 🎊!

Please include a description of your change and the problem it solves. Then check your PR against this list. Thanks!
- [ ] Commit message has a short title & issue references
- [ ] Commits are squashed
- [ ] The build will pass (run `bundle exec rake`).

More info can be found by clicking the "guidelines for contributing" link above.
