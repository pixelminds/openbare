module Bourbon
  VERSION = "5.0.0"
end
